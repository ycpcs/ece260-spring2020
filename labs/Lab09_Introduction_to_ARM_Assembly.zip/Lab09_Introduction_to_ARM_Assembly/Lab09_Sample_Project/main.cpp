#include "mbed.h"

Serial pc(USBTX, USBRX); // tx, rx

Timer t;

#define LIMIT 64
int data[LIMIT];

int main() 
{
    pc.baud(9600);  
    t.start();
    
    ////YOUR CODE BEGINS HERE///
    
    
    
    
    
    
    ///YOUR CODE STOPS HERE////
    t.stop();
    
    unsigned int time = t.read_us();
    
    pc.printf("CPU time is %i microseconds for LIMIT value of %i\r\n",time, LIMIT);
}

#ifndef _FUNCTIONS_H_
#define _FUNCTIONS_H_

#include <iostream>
#include <iomanip>
#include <string>
#include <thread>
using namespace std;


void print_ptr_info(string name, void* ptr);
int get_num_processors();


#endif

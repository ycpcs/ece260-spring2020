/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */
 
import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab04Part5Test {

    @Test(timeout=1000)  // 500
    public void verify_final_value_inited_to_7() {
        set(t0, 7);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=7, final value should be 17 -- ", 17, get(t0));
    }

    @Test(timeout=1000)  // 501
    public void verify_final_value_inited_to_15() {
        set(t0, 15);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=15, final value should be 25 -- ", 25, get(t0));
    }

    @Test(timeout=1000)  // 502
    public void verify_final_value_inited_to_16() {
        set(t0, 16);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=16, final value should be 26 -- ", 26, get(t0));
    }

    @Test(timeout=1000)  // 503
    public void verify_final_value_inited_to_17() {
        set(t0, 17);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=17, final value should be 14 -- ", 14, get(t0));
    }

    @Test(timeout=1000)  // 504
    public void verify_final_value_inited_to_18() {
        set(t0, 18);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=18, final value should be 15 -- ", 15, get(t0));
    }
}

/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */
 
import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab04Part2Test {

    @Test(timeout=1000)  // 200
    public void verify_final_value_inited_to_7() {
        set(t0, 7);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=7, final value should be 16 -- ", 16, get(t0));
    }

    @Test(timeout=1000)  // 201
    public void verify_final_value_inited_to_6() {
        set(t0, 6);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=6, final value should be 15 -- ", 15, get(t0));
    }

    @Test(timeout=1000)  // 202
    public void verify_final_value_inited_to_5() {
        set(t0, 5);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=5, final value should be 14 -- ", 14, get(t0));
    }

    @Test(timeout=1000)  // 203
    public void verify_final_value_inited_to_4() {
        set(t0, 4);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=4, final value should be 11 -- ", 11, get(t0));
    }

    @Test(timeout=1000)  // 204
    public void verify_final_value_inited_to_3() {
        set(t0, 3);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=3, final value should be 10 -- ", 10, get(t0));
    }
}

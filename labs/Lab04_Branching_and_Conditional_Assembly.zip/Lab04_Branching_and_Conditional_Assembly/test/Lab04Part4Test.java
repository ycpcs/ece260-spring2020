/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */
 
import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab04Part4Test {

    @Test(timeout=1000)  // 400
    public void verify_final_value_inited_to_7() {
        set(t0, 7);
        set(t1, 13);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=7, final value should be 5 -- ", 5, get(t0));
    }

    @Test(timeout=1000)  // 401
    public void verify_final_value_inited_to_12() {
        set(t0, 12);
        set(t1, 13);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=12, final value should be 10 -- ", 10, get(t0));
    }

    @Test(timeout=1000)  // 402
    public void verify_final_value_inited_to_13() {
        set(t0, 13);
        set(t1, 13);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=13, final value should be 11 -- ", 11, get(t0));
    }

    @Test(timeout=1000)  // 403
    public void verify_final_value_inited_to_14() {
        set(t0, 14);
        set(t1, 13);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=14, final value should be 9 -- ", 9, get(t0));
    }

    @Test(timeout=1000)  // 404
    public void verify_final_value_inited_to_15() {
        set(t0, 15);
        set(t1, 13);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=15, final value should be 10 -- ", 10, get(t0));
    }
}
